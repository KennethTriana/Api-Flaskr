from flask import jsonify, request
from flask_restful import Api, Resource
from flaskr.modelos.modelos import db, Categoria, CategoriaSchema
from marshmallow import ValidationError

categoria_schema = CategoriaSchema()

class VistaCategoria(Resource):
    def get(self):
        try:
            categorias = Categoria.query.all()  # Obtener todas las categorías
            return categoria_schema.dump(categorias, many=True), 200  # Devolverlas en formato JSON
        except Exception as e:
            return {'message': f'Error al obtener las categorías: {str(e)}'}, 500

    def post(self):
        try:
            # Recibimos solo el campo 'nombre'
            data = request.json

            # Validamos que 'nombre' esté presente
            if 'nombre' not in data:
                return {'message': 'El campo "nombre" es obligatorio.'}, 400

            # Crear una nueva categoría con el nombre
            nueva_categoria = Categoria(nombre=data['nombre'])
            db.session.add(nueva_categoria)
            db.session.commit()
            
            # Retornar la categoría creada en formato JSON
            return categoria_schema.dump(nueva_categoria), 201  # Código de estado correcto para creación
        except ValidationError as err:
            return {'message': f'Error en la validación: {err.messages}'}, 400
        except Exception as e:
            return {'message': f'Error inesperado: {str(e)}'}, 500

    def put(self, id):
        try:
            categoria = Categoria.query.get(id)
            
            if categoria:
                # Recibimos solo el campo 'nombre' para actualizar
                data = request.json

                # Validamos que 'nombre' esté presente
                if 'nombre' not in data:
                    return {'message': 'El campo "nombre" es obligatorio.'}, 400

                # Actualizamos el nombre de la categoría
                categoria.nombre = data['nombre']
                db.session.commit()

                # Devolver la categoría actualizada
                return categoria_schema.dump(categoria), 200
            else:
                return {'message': 'Categoría no encontrada'}, 404

        except ValidationError as err:
            return {'message': f'Error en los datos: {err.messages}'}, 400
        except Exception as e:
            return {'message': f'Error inesperado: {str(e)}'}, 500

    def delete(self, id):
        try:
            categoria = Categoria.query.get(id)
            
            if categoria:
                db.session.delete(categoria)
                db.session.commit()
                return {'message': 'Categoría eliminada exitosamente'}, 200
            else:
                return {'message': 'Categoría no encontrada'}, 404

        except Exception as e:
            return {'message': f'Error inesperado: {str(e)}'}, 500
