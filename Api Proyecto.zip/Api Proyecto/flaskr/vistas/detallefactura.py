from flask import jsonify, request
from flask_restful import Resource
from flaskr.modelos.modelos import db, DetalleFactura, DetalleFacturaSchema
from marshmallow import ValidationError

detalle_factura_schema = DetalleFacturaSchema()

class VistaDetalleFactura(Resource):
    def get(self):
        try:
            detalles = DetalleFactura.query.all()
            return [detalle_factura_schema.dump(detalle) for detalle in detalles], 200
        except Exception as e:
            return {'message': f'Error al obtener los detalles de factura: {str(e)}'}, 500

    def post(self):
        try:
            data = request.json
            # Validación básica de los datos
            if not all(key in data for key in ('cantidad', 'precio_unitario', 'inventario_id')):
                return {'message': 'Faltan datos requeridos.'}, 400

            # Crear el nuevo detalle de factura
            nuevo_detalle = DetalleFactura(
                cantidad=data['cantidad'],
                precio_unitario=data['precio_unitario'],
                inventario_id=data['inventario_id']
            )
            db.session.add(nuevo_detalle)
            db.session.commit()
            return detalle_factura_schema.dump(nuevo_detalle), 201  # Creación exitosa
        except ValidationError as err:
            return err.messages, 400
        except Exception as e:
            return {'message': f'Error al crear detalle de factura: {str(e)}'}, 500

    def put(self, id):
        try:
            detalle = DetalleFactura.query.get(id)
            if detalle:
                data = request.json
                detalle.cantidad = data.get('cantidad', detalle.cantidad)
                detalle.precio_unitario = data.get('precio_unitario', detalle.precio_unitario)
                detalle.inventario_id = data.get('inventario_id', detalle.inventario_id)
                db.session.commit()
                return detalle_factura_schema.dump(detalle), 200
            return {'message': 'Detalle de factura no encontrado'}, 404
        except Exception as e:
            return {'message': f'Error al actualizar detalle de factura: {str(e)}'}, 500

    def delete(self, id):
        try:
            detalle = DetalleFactura.query.get(id)
            if detalle:
                db.session.delete(detalle)
                db.session.commit()
                return '', 204  # Eliminado con éxito, sin cuerpo
            return {'message': 'Detalle de factura no encontrado'}, 404
        except Exception as e:
            return {'message': f'Error al eliminar detalle de factura: {str(e)}'}, 500
